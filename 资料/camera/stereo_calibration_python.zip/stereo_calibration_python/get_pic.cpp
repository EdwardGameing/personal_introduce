#include<iostream>
#include<opencv2/core.hpp>
#include<opencv2/opencv.hpp>
#include<opencv2/highgui.hpp>
#include<string>
#include <time.h>
#include<vector>
#include<thread>
using namespace cv;
using namespace std;

int get_pic(int n=0)
{
    Mat img;
    int k;
    VideoCapture cap(0);
    if (!cap.isOpened())
        return 1;
    int count =n;
    cap.set(CV_CAP_PROP_FRAME_WIDTH, 1280);
    cap.set(CV_CAP_PROP_FRAME_HEIGHT, 480);
    cv::Rect rect1(0, 0, 640, 480);
    cv::Rect rect2(640, 0, 640, 480);
    cap.set(cv::CAP_PROP_FPS, 60);

    cap.set(CAP_PROP_FOURCC, CV_FOURCC('M', 'J', 'P', 'G'));
    while (1) {

        cap >> img;
        imshow("show", img);
        
        k = waitKey(1);
        if (k == 's')  //��s����ͼƬ
            {
                string str;
                imwrite("D:\\check_box\\L" + to_string(count) + ".jpg", img(rect1));
                imwrite("D:\\check_box\\R" + to_string(count) + ".jpg", img(rect2));
                cout << "save pic done" << endl;
                count = count + 1;
            }
        else if (k == 27)//Esc��
            break;
    }
    return 0;
}

int get_steropic(int n = 0) {
    Mat img1,img2;
    int k;
    VideoCapture cap1(3);
    VideoCapture cap2(2);
    if (!cap2.isOpened() && !cap1.isOpened())
        return 1;
    int count = n;
    cap1.set(CV_CAP_PROP_FRAME_WIDTH, 680);
    cap1.set(CV_CAP_PROP_FRAME_HEIGHT, 480);
    cap2.set(CV_CAP_PROP_FRAME_WIDTH, 680);
    cap2.set(CV_CAP_PROP_FRAME_HEIGHT, 480);

    cv::Rect rect1(0, 0, 640, 480);
    cv::Rect rect2(0, 0, 640, 480);
    while (1) {
        if (!cap2.isOpened() || !cap1.isOpened())
            return 1;
        cap1 >> img1;
        cap2 >> img2;
        imshow("showL", img1);
        imshow("showR", img2);

        k = waitKey(250);
        if (k !=27)//��s����ͼƬ
        {
            string str;
            string head;
            if (count < 100 && count>10)
            {
                head = "00000000000000000";
            }
            else if (count < 10)
            {
                head = "000000000000000000";
            }
            else
                head = "0000000000000000";

            imwrite("D:\\check_box\\L\\" + head + to_string(count) + ".jpg", img1);
            imwrite("D:\\check_box\\R\\" + head+ to_string(count) + ".jpg", img2);
            cout << "save pic done" << endl;
            img1.release();
            img2.release();
            count = count + 1;
        }
        else if (k == 27)//Esc��
            break;
    }
    return 0;

}
int get_steropic_cv(string img_path = "D:\\check_box\\orb\\", int n = 0) {
    Mat img1, img2;
    int k;
    VideoCapture cap1(0);
    VideoCapture cap2(3);
    if (!cap2.isOpened() && !cap1.isOpened())
        return 1;
    int count = n;
    cap1.set(CV_CAP_PROP_FRAME_WIDTH, 680);
    cap1.set(CV_CAP_PROP_FRAME_HEIGHT, 480);
    cap2.set(CV_CAP_PROP_FRAME_WIDTH, 680);
    cap2.set(CV_CAP_PROP_FRAME_HEIGHT, 480);

    cv::Rect rect1(0, 0, 640, 480);
    cv::Rect rect2(0, 0, 640, 480);
    float fps1, fps2,e,s;
    int count_time = 0;
    fps1 = cap1.get(cv::CAP_PROP_FPS);
    fps2 = cap2.get(cv::CAP_PROP_FPS);

    cout << "capL: " << to_string(fps1) << endl;
    cout << "capR: " << to_string(fps1) << endl;
    clock_t start, ends;
    int pre_start=0;
    while (1) {
        if (!cap2.isOpened() || !cap1.isOpened())
            return 1;
        cap1 >> img1;
        cap2 >> img2;
        /*
        count_time++;
        start = clock();
        if (count_time == 1)  s = start;
        
        if (count_time == 300)
        {
            e = start;
            break;

        }
        
        cout << "time" << start << "============" << count_time << "===========" <<(start-pre_start) << endl;
        pre_start = start;*/
        
        imshow("showL", img1);
        imshow("showR", img2);

        k = waitKey(1);
        if (k == 's')//��s����ͼƬ
        {
            string str;
            imwrite(img_path + "L" + to_string(count) + ".jpg", img1);
            imwrite(img_path + "R" + to_string(count) + ".jpg", img2);
            cout << "save pic done" << endl;
            img1.release();
            img2.release();
            count = count + 1;
        }
        else if (k == 27)//Esc��
            break;
    }
    //cout << "fps:" << 300 / ((e - s) / 1000);

    return 0;
}

void get_pic_cv(int time_list[],string img_path = "D:\\check_box\\orb\\", int n = 0,
                       int cap_num = 0) {
    Mat img;
    int k;
    
    VideoCapture cap(cap_num);

    int count = n;
    //cap.set(CV_CAP_PROP_FRAME_WIDTH, 1280);
    //cap.set(CV_CAP_PROP_FRAME_HEIGHT, 480);
    //cv::Rect rect1(0, 0, 640, 480);
    //cv::Rect rect2(640, 0, 640, 480);
    float fps,s,e;
    cap.set(cv::CAP_PROP_FPS, 60);
    fps = cap.get(cv::CAP_PROP_FPS);
    cap.set(6, cv::CAP_OPENCV_MJPEG);
    cout<<to_string(fps)<<endl;
    int count_time = 0;
    clock_t start, ends;
    while (1) {
        cap >> img;
        count_time++;

        start   = clock();
        if (count_time == 1)  s = start;
        if (count_time == 300)
        {
            e = start;
            break;
        
        }
        //cout << "time" << start << "============" << count_time << endl;
        //cout << start << "================="<< "cap:" << cap_num << endl;
        time_list[count_time] = start;
        
        /*imshow("show", img);

        
        k = waitKey(20);
        if (k == 's')//��s����ͼƬ
        {
            string str;

            imwrite(img_path + "L" + to_string(count) + ".jpg", img(rect1));
            imwrite(img_path + "R" + to_string(count) + ".jpg", img(rect2));
            cout << "save pic done" << endl;
            count = count + 1;
        }
        else if (k == 27)//Esc��
            break;*/
    }
    //cout << "fps:" << 300 / ((e - s) / 1000);
    return;
}


int main() {
    // Use to streo calibration 
    //get_pic();
    // Use docker calibration
    //get_steropic();

    // �úڰ����̸�궨�������
    get_steropic_cv();
    //
    //get_pic();
  /*
    bool start = false;
    int time_list0[300] = {0};
    int time_list1[300] = {0};
    thread th0(get_pic_cv, time_list0, "D:\\check_box\\orb\\", 0, 0);
    thread th1(get_pic_cv, time_list1, "D:\\check_box\\orb\\", 0, 1);

    th0.join();
    th1.join();
    for (int i = 1; i < 300; i++) {
      cout << time_list0[i] - time_list0[1] << "==========cap_1   ";
      cout << time_list1[i] - time_list1[1] << "==========cap_2" << endl;
    }*/
    //get_pic_cv();

    return 0;
}
