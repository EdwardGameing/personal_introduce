#pragma once
int get_pic(int n);