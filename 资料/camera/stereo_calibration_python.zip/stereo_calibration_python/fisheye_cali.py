import cv2 as cv
import numpy as np
import json
import os
class camera():
    def __init__(self,img_path = "D:/check_box/",img_num=17,square_size=56.286,side = "L",board_size=(7,5)):
        self.imageFileName = img_path
        self.square_size = square_size
        self.side = side
        self.board_size = board_size
        self.img_list = []
        self.avi_corners = 0
        self.calied = False
        self.CBoardJson = []
        self.CBoardJsonAll = []
        self.img_list_s = []
        # for i in range(img_num):
        #     self.img_list.append((self.imageFileName + side + str(i) + ".jpg"))

        for i in os.listdir("C:/Users/jinzhao/Desktop/pics"):
            self.img_list.append(os.path.join("C:/Users/jinzhao/Desktop/pics",i))
            self.img_list_s.append(i)
    def cali(self):
        org_corners,_ = self.findcorners()
        corners = []
        for i in org_corners:
            if i[0][0][0] != 0:
                corners.append(i)
        print(len(corners))
        object_Points = self.markchessboard()
        K = np.zeros((3, 3))
        D = np.zeros((4, 1))
        calibration_flags = cv.fisheye.CALIB_RECOMPUTE_EXTRINSIC + cv.fisheye.CALIB_CHECK_COND + cv.fisheye.CALIB_FIX_SKEW
        rvecs = [np.zeros((1, 1, 3), dtype=np.float64) for i in range(len(object_Points))]
        tvecs = [np.zeros((1, 1, 3), dtype=np.float64) for i in range(len(object_Points))]
        rms, _, _, _, _ = \
            cv.fisheye.calibrate(
                object_Points,
                corners,
                self.img_size,
                K,
                D,
                rvecs,
                tvecs,
                calibration_flags,
                (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 1e-6))
        DIM = self.img_size[::-1]
        self.K = K
        self.D = D
        self.test = np.array([[400, 0.0, 300], [0.0, 400, 200], [0.0, 0.0, 1.0]])
        print("Found " + str(len(object_Points)) + " valid images for calibration")
        print("DIM=" + str(self.img_size[::-1]))
        print("K=np.array(" + str(K.tolist()) + ")")
        print("D=np.array(" + str(D.tolist()) + ")")
        self.calied = True
        return DIM, K, D

    def undistortPoint(self,points):
        if self.calied == False:
            self.cali()
        points = np.expand_dims(points,0)
        points = np.expand_dims(points, 0)
        out_points = cv.fisheye.undistortPoints(points,K = self.K,D = self.D,P=self.P)
        fx = self.K[0, 0]
        fy = self.K[1, 1]
        cx = self.K[0, 2]
        cy = self.K[1, 2]
        out_points = np.squeeze(out_points)
        point2d = np.zeros((2,))
        point2d[0] = out_points[0] * fx + cx
        point2d[1] = out_points[1] * fy + cy

        return out_points #point2d
    def test_new_func(self):
        self.K = np.array([[283.01506566385905, 0.0, 309.42098232331125], [0.0,  278.8229644810026, 241.22783371057483],[0.0, 0.0, 1.0]])
        self.D = np.array([[-0.0044708424742620784, -0.004006959560954281, 0.05845208676931294,
    -0.0405038612276777]])
    def undistortImg(self,img_path):
        undistort_img = cv.imread(img_path)
        if self.calied == False:
            self.cali()
        # out_img = cv.fisheye.undistortImage(undistort_img,self.K, self.D,self.K) //
        map1, map2 = cv.fisheye.initUndistortRectifyMap(self.K, self.D, np.eye(3), self.P,(640,480), cv.CV_16SC2)
        out_img = cv.remap(undistort_img, map1, map2, interpolation=cv.INTER_LINEAR, borderMode=cv.BORDER_CONSTANT)
        # cv.imshow("res",undistorted_img)
        # cv.imwrite("./undistortImg.jpg",undistorted_img)
        # cv.waitKey()
        return out_img

    def distortPoint(self,points):
        pass

    def estimateNewCameraMatrix(self):
        self.P = cv.fisheye.estimateNewCameraMatrixForUndistortRectify(self.K,self.D,self.img_size,np.eye(3))
        print(self.P)

    def markchessboard(self):
        object_Points = []
        objp = np.zeros((1, self.board_size[0] * self.board_size[1], 3), np.float32)
        objp[0, :, :2] = np.mgrid[0:self.board_size[0], 0:self.board_size[1]].T.reshape(-1, 2) * self.square_size

        # # 切换左手坐标系
        # objp[:,:,1] = 78 -objp[:,:,1]

        for _ in range(self.avi_corners):
            object_Points.append(objp)
        return object_Points

    def findcorners(self):
        corners = []
        indexs = []
        count = 0

        for index, i in enumerate(self.img_list):
            CBoardJson = []
            img = cv.imread(i,0)
            rgb_img = cv.imread(i)
            ok, corner = cv.findChessboardCorners(img, self.board_size, None)
            if not ok:
                corners.append([[[0.0,0.0]]*24])
                continue
            corner = corner.astype("float64")
            if len(corner)!= self.board_size[0]*self.board_size[1]:
                print("corner excption:",len(corner))
            corners.append(corner)
            indexs.append(index)
            if ok:
                CBoardJson.append(self.img_list_s[count])
                print("img_path : "+ self.img_list[count] + " num : "+ str(count))
                count += 1
                #self.CBoardJson.append("./results/conner" + self.side + str(index) + ".jpg")
                for pt in corner:
                    point = pt[0]
                    cv.circle(rgb_img, center=(int(point[0]), int(point[1])), radius=3, color=(0, 255, 0), thickness=-1)
                    CBoardJson.append([int(point[0]), int(point[1])])
                self.CBoardJsonAll.append(CBoardJson)

                #cv.imwrite("./results/conner" + self.side + str(index) + ".jpg", rgb_img)
            else:
                print('cannot find chessboard points')
            self.img_size = img.shape[::-1]
        print("角点提取完成,成功提取图片数目为:", count)
        self.conners = corners
        self.avi_corners = len(indexs)
        return corners,indexs

    def writeJson(self):
        with open("./results/chessboard.json", 'w+') as f:
            data = []
            for i in self.CBoardJsonAll:
                #data.append({"img_dir": i[0], "corners": i[1:]})
                data.append(i)
            json_data = json.dumps(data, indent=4,separators=(',', ': '))
            f.write(json_data)


if __name__ == '__main__':
    # cam1 = camera(img_num=14,side="R",square_size=44.25)
    # #chessboard = cam1.markchessboard()
    # pic_num = 9
    # origin = cv.imread(cam1.img_list[pic_num])
    # cor_points = []
    # cam1.cali()
    # cam1.estimateNewCameraMatrix()
    # #cam1.test_new_func()
    # img = cam1.undistortImg(cam1.img_list[pic_num])
    # for index,i in enumerate(cam1.conners[pic_num]):
    #     point = i[0]
    #     res = cam1.undistortPoint(point)
    #     cor_points.append(res)
    #     cv.circle(origin, center=(int(point[0]), int(point[1])), radius=3, color=(0, 0, 255), thickness=-1)
    #     # res = np.squeeze(res)
    #     # point2d = np.zeros((2,))
    #     # point2d[0] = res[0] * fx + cx
    #     # point2d[1] = res[1] * fy + cy
    #     cv.circle(img,(int(res[0]), int(res[1])),3,(0,0,255),-1)
    # #[-0.014503597720920568], [0.029501995548399166], [0.012759937592137172], [-0.019211719473270168]]
    # #[-0.01672282095364774], [0.04120086605867518], [-0.007966494429753699], [-0.007703202522288842]]
    # cv.imwrite("./results/origin"+str(pic_num)+".jpg", origin)
    # cv.imwrite("./results/distor"+str(pic_num)+".jpg",img)
    # cv.waitKey()

    cam1 = camera(img_num=14, side="R", square_size=41.13)
    chessboard = cam1.markchessboard()
    cam1.findcorners()
    cam1.writeJson()
    # pic_num = 9
    # origin = cv.imread(cam1.img_list[pic_num])
    # cor_points = []
    # cam1.cali()