from fisheye_cali import camera
import numpy as np
import cv2 as cv
from scipy.spatial.transform import Rotation as R
import json
import os
class stereo():                                           #181% -> 56.3mm(6,4), 194% ->44.25(7,5) ，181% ->41.13(7,5)
    def __init__(self,img_path = "D:/check_box/",img_num=13,square_size=41.13,board_size=(7,5),json_path = "./results/stereo_cali.json"):
        self.cam1 = camera(img_num=img_num,side="L",square_size=square_size,board_size = board_size)
        self.cam2 = camera(img_num=img_num,side="R",square_size=square_size,board_size = board_size)
        self.imageFileName = img_path
        self.square_size = square_size
        self.board_size = board_size
        self.img_list = []
        self.calied = False
        self.img_num = img_num
        self.json_path = json_path
        if os.path.exists("./results")==False:
            os.mkdir("./results")
        self.corners1 = []
        self.corners2 = []
    def undistorted(self, pointl, pointr):
        res1 = self.cam1.undistortPoint(pointl)
        res2 = self.cam2.undistortPoint(pointr)
        return res1, res2

    def calibration(self):
        self.cam1.cali()
        self.cam2.cali()
        object_Points = self.cam1.markchessboard()
        corners1,indexs1 = self.cam1.findcorners()
        corners2,indexs2 = self.cam2.findcorners()

        commonEle = [val for val in indexs1 if val in indexs2]

        R = np.array([])
        T = np.array([])
        calibration_flags = cv.fisheye.CALIB_RECOMPUTE_EXTRINSIC + cv.fisheye.CALIB_CHECK_COND + cv.fisheye.CALIB_FIX_SKEW
        test_object = []
        for i in range(len(commonEle)):
            test_object.append(np.zeros((self.board_size[0]*self.board_size[1], 1, 3), dtype=float))
            for j in range(self.board_size[0]*self.board_size[1]):
                test_object[i][j, :, :] = object_Points[i][0, j, :]

        #cv.fisheye.stereoCalibrate(test_object, corners1, corners2, self.cam1.K, self.cam1.D, self.cam2.K, self.cam2.D,
        #                           self.cam1.img_size, R, T)
        k1 = self.cam1.K
        k2 = self.cam2.K
        d1 = self.cam1.D
        d2 = self.cam2.D
        for i in commonEle:
            self.corners1.append(corners1[i])
            self.corners2.append(corners2[i])
        retval, K1, D1, K2, D2, R, T = cv.fisheye.stereoCalibrate(test_object, self.corners1, self.corners2, k1, d1, k2, d2, (640, 480),R,T)
        self.R = R
        self.T = T
        print(retval)

    def stereoRectify(self):
        # R1, R2, P1, P2, Q = cv.stereoRectify(self.cam1.K, self.cam1.D,self.cam2.K,self.cam2.D, (640, 480),
        #               self.R, self.T, cv.CALIB_ZERO_DISPARITY,(640, 480))
        self.R1,self.R2,self.P1,self.P2,self.Q= cv.fisheye.stereoRectify(self.cam1.K, self.cam1.D, self.cam2.K, self.cam2.D, (640, 480),
                                             self.R, self.T,cv.CALIB_ZERO_DISPARITY,(640, 480))


    # 需要先 undistorted
    def pushPoint(self, pointsL, pointsR):
        undistort_l, undistort_r = self.undistorted(pointsL, pointsR) # 需要先 undistorted
        #print("---"*20)
        undistort_l[1] = 480 - undistort_l[1]
        undistort_r[1] = 480 - undistort_r[1]
        #print("undistort point 0: ",undistort_r)
        P1_test = self.cam1.P.copy()
        P1_test[1][2] = 480. - P1_test[1][2]
        P2_test = self.cam2.P.copy()
        P2_test[1][2] = 480. - P2_test[1][2]

        new_P1 = P1_test @ np.concatenate((self.R1,self.T1),axis=1)
        new_P2 = P2_test @ np.concatenate((self.R2,self.T2),axis=1)

        # print("new_P1",new_P1)
        # print("new_P2", new_P2)
        points_3d = cv.triangulatePoints(new_P1,new_P2,undistort_l, undistort_r)
        points_2d = cv.projectPoints(points_3d[:3],self.R1,self.T1,P1_test,0)

        #print("#=#" * 20)
        points_3d /= points_3d[-1]
        resl = new_P1@points_3d
        resr = new_P2 @ points_3d
        # points_3d = cv.triangulatePoints(new_P2, new_P1, undistort_r, undistort_l)
        resl /= resl[-1]
        resr /= resr[-1]

        print(resr)
        return points_3d

    def compute_R(self):
        k1_lin = np.linalg.inv(self.cam2.P)
        # k1_lin = np.linalg.inv(self.cam1.K)
        r2_pre = k1_lin @ self.P2

    def transformR(self):
        R1 = R.from_matrix([[1.,0.,0.],
                            [0.,1.,0.],
                            [0.,0.,1.]])
        #testt = np.array([1,2,3]).transpose()
        #print(self.R@testt)
        R2 = R.from_matrix(self.R)   ## 旋转矩阵 -> 四元数
        R1 = R.as_quat(R1)
        R2 = R.as_quat(R2)

        self.R2_q = [-R2[0], R2[1], -R2[2], R2[3]]
        test2 = [R2[3], -R2[2], -R2[1], R2[0]]

        # print(R.from_quat(self.R2_q).apply([1,-2,3]))
        #
        # print(R.from_quat(test2).apply([1,-2,3]))

        R_test1 = R.from_quat(self.R2_q)
        R_test2 = R.from_quat(test2)
        # 轴
        self.R1 = np.array([[1.,0.,0.],
                            [0.,1.,0.],
                            [0.,0.,1.]])
        self.T1 = np.array([0.,0.,0.]).reshape(3,1)
        self.R2 = R.as_matrix(R_test1)
        self.T2 = self.T
        self.T2[1] = - self.T[1]
        self.R1_q = R1

        R_test1 = np.array(R.as_matrix(R_test1))@np.array([1,-2 ,3]).transpose()
        R_test2 = np.array(R.as_matrix(R_test2))@np.array([1,-2 ,3]).transpose()

    def testCamM(self):
        self.cam1.estimateNewCameraMatrix()   # 反扭曲过后平面相机的内参矩阵  K -> P
        self.cam2.estimateNewCameraMatrix()

        P1_test = self.cam1.P.copy()
        P1_test[1][2] =480 - P1_test[1][2]
        # P2_test = np.array([[206.43937401, 0., 347.81095908],
        #                      [0.,206.7027645 ,480 - 260.34884038],
        #                      [0.,0.,1.]])
        self.P1 = self.cam1.P @ np.concatenate((self.R1,self.T1),axis=1)
        self.P2 = self.cam2.P @ np.concatenate((self.R2,self.T2),axis=1)

    def write_json(self):
        camera_dict = {"camera1.K":self.cam1.K.tolist(),"camera1.D":self.cam1.D.tolist(),"camera1.P":self.cam1.P.tolist(),"camera2.K":self.cam2.K.tolist(),"camera2.D":self.cam2.D.tolist(),
                       "camera2.P":self.cam2.P.tolist(),"stereo_R1":np.array(self.R1_q).tolist(),"stereo_T1":self.T1.tolist(),"stereo_R2":np.array(self.R2_q).tolist(),"stereo_T2":self.T2.tolist(),"stereo_P1":self.P1.tolist(),
                       "stereo_P2":self.P2.tolist()}
        with open(self.json_path, 'w+') as f:
            json_data = json.dumps(camera_dict,indent=4,separators=(',', ': '))
            f.write(json_data)
            print("json_file writing done...")
    def forward(self):
        self.calibration()
        self.transformR()
        self.testCamM()
        self.write_json()


def test_err():   #测试一下3d point上 图像上是一条直线的角点，在3d上线性关系如何
    for i in range(24):

        pointsL = [stereo1.corners1[img][i, 0, 0], 480 - stereo1.corners1[img][i, 0, 1]]
        pointsR = [stereo1.corners2[img][i, 0, 0], 480 - stereo1.corners2[img][i, 0, 1]]
        #undistort_l, undistort_r = stereo1.undistorted(pointsL, pointsR)
        # last_point x +4px
        # if i == 5:
        #     pointsL[0] = pointsL[0] + 4
        #     pointsR[1] = pointsR[1] - 4

        points = stereo1.pushPoint(pointsL, pointsR)
        points = np.array(points)
        points = points/points[-1]
        # if 0 <= i < 6:
        #     res.append(points)
        res.append(points)
    #stereo1.compute_R()
    for i in range(6):
        p1 = res[0] + 0.2 * i * (res[5] - res[0])
        print(p1 - res[i])
        if i !=5:
            print("x_distance====",np.sqrt(np.sum((res[i+1]-res[i])**2)))
            print("y_distance====",np.sqrt(np.sum((res[6+i]-res[i])**2)))



    # for i in range(4):
    #     show_res = res[i*6:i*6+6]
    #     for j in range(6):
    #         print("x: ",show_res[j][0],"y: ",show_res[j][1],"z: ",show_res[j][2])
    #     print("####"*20)

    # new_P1 = np.array([[206.48453464,0.,347.67466808,0.],[0.,206.340389,178.81695,0.],[0.,0.,1.,0.]])
    # new_P2 = np.array([[2.27486015e+02,1.34218853e+01,3.47555214e+02,-2.20961871e+04],[6.08952857e+00,2.10746454e+02,2.28213973e+02,-1.52829680e+03],[5.90277576e-02,1.67535024e-02,9.98115747e-01,-5.61438541e+00]])
    # print(res[0])
    # pointl2d = new_P1@res[0]
    # pointr2d = new_P2@res[0]
    # print(pointr2d/pointr2d[-1])


stereo1 = stereo()
# stereo1.calibration()
# stereo1.transformR()
# stereo1.testCamM()
stereo1.forward()

img = 9
res = []
test_err()
stereo1.write_json()


# print("------", i, "-------------")
#
# print(undistort_l)
# print(undistort_r)
# pixl=  stereo1.P1@points
# pixl /= pixl[-1]
# pixr = stereo1.P2@points
# pixr /= pixr[-1]
# print("---------projected----------")
# print(pixl)
# print(pixr)
# print("----------project diff ori--------------")
# print(pixl[0] - pointsL[0], "   ",pixl[1] - pointsL[1] )
# print(pixr[0] - pointsR[0], "   ", pixr[1] - pointsR[1])



